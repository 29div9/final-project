package org.capgemini.capstore.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.validation.Valid;

import org.capgemini.capstore.domain.Promo;
import org.capgemini.capstore.service.PromoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.http.HttpStatus;

@Controller
//@RequestMapping("/promoCntlr")
public class PromoController {
	
	@Autowired
	private PromoService promoService;
	
	
	@RequestMapping("/promo")
	public String showPromoForm(Map<String, Object> maps)
	{
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		maps.put("pro", new Promo());
		return "PomoForm";
	}
	
	@RequestMapping(value="/savePromo",method=RequestMethod.POST)
	public String showPromoDetails(Map<String, Object> map,
			@Valid @ModelAttribute("pro") Promo promo,
			BindingResult result)
	{
		List<Promo> promos= promoService.getAllPromos();
		System.out.println(promos);
		map.put("proms",promos);
		/*if(result.hasErrors())
			return new ModelAndView("PromoForm");
		else			
		{*/		
		promoService.savePromo(promo);
		return "redirect:/promo";
		
	//}

}
	/*@RequestMapping(value="/showPromoDetails")
	public String displayAllPromos(Map<String, Object> map,
			@Valid @ModelAttribute("pro") Promo promo,
			BindingResult result)
	{
		List<Promo> promos= promoService.getAllPromos();
		
		System.out.println("details"+promos);
		map.put("proms",promos);
		return "showPromo";
		
	}*/
	
	@RequestMapping(value="/showPromoNames")
	public String displayPromoNames(Map<String,Object> map,
			@Valid @ModelAttribute("pro") Promo promo,
			BindingResult result)
	{
		List<Objects []> promoNames=promoService.getPromoNames();
		//System.out.println("names"+promoNames);
		map.put("promoName", promoNames);
		return "showPromoNames";
	}
	
	
	@RequestMapping(value="/showPromoDetails",
			produces={"application/json"})
	@ResponseStatus(HttpStatus.OK)
	public @ResponseBody ModelAndView getAllDepartments(){
		List<Objects []> pro=promoService.getPromoNames();
		List<Promo> promos= promoService.getAllPromos();
		return new ModelAndView("showPromo","msg","on showpromo page");
}
}
