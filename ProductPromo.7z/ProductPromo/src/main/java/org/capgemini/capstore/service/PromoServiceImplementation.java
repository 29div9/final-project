package org.capgemini.capstore.service;

import java.util.List;
import java.util.Objects;

import org.capgemini.capstore.dao.PromoDao;
import org.capgemini.capstore.domain.Promo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class PromoServiceImplementation implements PromoService{
	
	@Autowired
	private PromoDao promoDao;

	@Override
	@Transactional
	public void savePromo(Promo promo) {
	
		promoDao.savePromo(promo);
	}

	@Override
	@Transactional
	public List<Promo> getAllPromos() {
		return promoDao.getAllPromos();
	}

	@Override
	public List<Objects []> getPromoNames() {
	
		return promoDao.getPromoNames();
	}

}
