package org.capgemini.capstore.dao;

import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpSession;

import org.capgemini.capstore.domain.Promo;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.CriteriaQuery;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class PromoDaoImplementation implements PromoDao{
	
	//HttpSession session=request.getSession(false);
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override

	public void savePromo(Promo promo) {
		sessionFactory.getCurrentSession().saveOrUpdate(promo);
		
	}


	@Override
	public List<Promo> getAllPromos() {
		return sessionFactory.getCurrentSession().createQuery("from Promo").list();
	}


	@Override
	@Transactional
	public List<Objects []> getPromoNames() {
		//Transaction tx = null;
		Session session=this.sessionFactory.getCurrentSession();
		session.beginTransaction();
 	// tx = session.beginTransaction();
		/*Criteria criteria = session.createCriteria(Promo.class);
		return criteria.setProjection(Projections.property("promoProductName")).list();*/
		
		
		List <Objects []> rows = sessionFactory.getCurrentSession().createQuery("select promoProductName from Promo").list();
		/*for(Object [] row : rows)
		{
			if(login.getEmail_id().equals(row[0])&&login.getPassword().equals(row[1]))
			{System.out.println(row[0]);
			System.out.println(row[1]);
			}
			else
				System.out.println("Not found");
				
		}*/
		
		return rows;
	
}
		
		
		
	}
	 
	



