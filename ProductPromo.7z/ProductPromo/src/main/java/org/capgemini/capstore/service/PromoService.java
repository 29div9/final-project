package org.capgemini.capstore.service;

import java.util.List;
import java.util.Objects;

import org.capgemini.capstore.domain.Promo;

public interface PromoService {
	public void savePromo(Promo promo);
	public List<Promo> getAllPromos();
	public List<Objects []> getPromoNames();
}
