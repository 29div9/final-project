var app=angular.module('promoApp',[]);

app.controller("ctrl",function($scope,$http){
	$http.get("http://localhost:8080/ProductPromo/showPromoDetails").
	success(function(data){
		$scope.promolist=data;
	});
	
	
});