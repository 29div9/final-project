package org.capgemini.capstore.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Promo {
	@Id
	@GeneratedValue
	private int promoId;
	
	/*@Column(nullable=false)*/
	private String promoProductName;
	
	
	/*@Column(nullable=false)*/
	private String promoDescription;
	
	/*@Column(nullable=false)
    private Image promoImage;*/
	
/*	@Column(nullable=false)*/
    private Date beginDate;
	
/*	@Column(nullable=false)*/
    private Date expiryDate;
	
	
    private String url;
   

	public int getPromoId() {
		return promoId;
	}

	public void setPromoId(int promoId) {
		this.promoId = promoId;
	}

	public String getPromoProductName() {
		return promoProductName;
	}

	public void setPromoProductName(String promoProductName) {
		this.promoProductName = promoProductName;
	}

	public String getPromoDescription() {
		return promoDescription;
	}

	public void setPromoDescription(String promoDescription) {
		this.promoDescription = promoDescription;
	}

	public Date getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(Date beginDate) {
		this.beginDate = beginDate;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((beginDate == null) ? 0 : beginDate.hashCode());
		result = prime * result + ((expiryDate == null) ? 0 : expiryDate.hashCode());
		result = prime * result + ((promoDescription == null) ? 0 : promoDescription.hashCode());
		result = prime * result + promoId;
		result = prime * result + ((promoProductName == null) ? 0 : promoProductName.hashCode());
		result = prime * result + ((url == null) ? 0 : url.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Promo other = (Promo) obj;
		if (beginDate == null) {
			if (other.beginDate != null)
				return false;
		} else if (!beginDate.equals(other.beginDate))
			return false;
		if (expiryDate == null) {
			if (other.expiryDate != null)
				return false;
		} else if (!expiryDate.equals(other.expiryDate))
			return false;
		if (promoDescription == null) {
			if (other.promoDescription != null)
				return false;
		} else if (!promoDescription.equals(other.promoDescription))
			return false;
		if (promoId != other.promoId)
			return false;
		if (promoProductName == null) {
			if (other.promoProductName != null)
				return false;
		} else if (!promoProductName.equals(other.promoProductName))
			return false;
		if (url == null) {
			if (other.url != null)
				return false;
		} else if (!url.equals(other.url))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Promo [promoId=" + promoId + ", promoProductName=" + promoProductName + ", promoDescription="
				+ promoDescription + ", beginDate=" + beginDate + ", expiryDate=" + expiryDate + ", url=" + url + "]";
	}

	public Promo(int promoId, String promoProductName, String promoDescription, Date beginDate, Date expiryDate,
			String url) {
		super();
		this.promoId = promoId;
		this.promoProductName = promoProductName;
		this.promoDescription = promoDescription;
		this.beginDate = beginDate;
		this.expiryDate = expiryDate;
		this.url = url;
	}

	public Promo() {
		super();
	}
	
	
}
